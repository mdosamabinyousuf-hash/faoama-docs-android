import fs from 'node:fs';
fs.mkdirSync('dist',{recursive:true});
let html=fs.readFileSync('index.html','utf8');
const css=fs.readFileSync('app.css','utf8');
let js=fs.readFileSync('app.js','utf8');
for(const name of ['logo.svg','shop-logo.svg']){
  const data='data:image/svg+xml;base64,'+fs.readFileSync(name).toString('base64');
  js=js.replaceAll(name,data);
}
html=html.replace('<link rel="manifest" href="manifest.webmanifest">','')
 .replace('<link rel="stylesheet" href="app.css">',`<style>${css}</style>`)
 .replace('<script src="app.js"></script>',`<script>${js}</script>`);
fs.writeFileSync('dist/Faoama-Docs-Test.html',html);
